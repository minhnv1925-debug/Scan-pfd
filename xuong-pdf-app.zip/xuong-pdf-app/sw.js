/* Xưởng PDF service worker, phiên bản 20261025-0124 */
const VERSION = 'xuongpdf-20261025-0124';
const CORE = ["./", "index.html", "manifest.webmanifest", "fonts/fonts.css", "lib/pdf.min.js", "lib/pdf.worker.min.js", "lib/pdf-lib.min.js", "icons/icon-192.png", "icons/favicon-32.png", "icons/apple-touch-icon.png", "fonts/be-vietnam-pro-latin-400-normal.woff2", "fonts/be-vietnam-pro-latin-500-normal.woff2", "fonts/be-vietnam-pro-latin-600-normal.woff2", "fonts/be-vietnam-pro-latin-700-normal.woff2", "fonts/be-vietnam-pro-latin-ext-400-normal.woff2", "fonts/be-vietnam-pro-latin-ext-500-normal.woff2", "fonts/be-vietnam-pro-latin-ext-600-normal.woff2", "fonts/be-vietnam-pro-latin-ext-700-normal.woff2", "fonts/be-vietnam-pro-vietnamese-400-normal.woff2", "fonts/be-vietnam-pro-vietnamese-500-normal.woff2", "fonts/be-vietnam-pro-vietnamese-600-normal.woff2", "fonts/be-vietnam-pro-vietnamese-700-normal.woff2", "fonts/ibm-plex-mono-latin-400-normal.woff2", "fonts/ibm-plex-mono-latin-500-normal.woff2"];

self.addEventListener('install', e => {
  e.waitUntil(caches.open(VERSION).then(c => c.addAll(CORE)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', e => {
  e.waitUntil((async () => {
    for (const k of await caches.keys()) if (k !== VERSION && k !== 'xuongpdf-inbox') await caches.delete(k);
    await self.clients.claim();
  })());
});

self.addEventListener('fetch', e => {
  const req = e.request;
  const url = new URL(req.url);
  // Android: nhận file được chia sẻ vào ứng dụng
  if (req.method === 'POST' && url.searchParams.has('share-target')) {
    e.respondWith((async () => {
      const form = await req.formData();
      const files = form.getAll('files').filter(f => f && typeof f !== 'string');
      const inbox = await caches.open('xuongpdf-inbox');
      for (const k of await inbox.keys()) await inbox.delete(k);
      await Promise.all(files.map((f, i) => inbox.put(new Request(`./__inbox__/${i}`),
        new Response(f, { headers: { 'x-name': encodeURIComponent(f.name || `file_${i + 1}`), 'content-type': f.type || 'application/octet-stream' } }))));
      return Response.redirect(new URL(`./?received=${files.length}`, self.registration.scope).href, 303);
    })());
    return;
  }
  if (req.method !== 'GET' || url.origin !== location.origin) return;
  // trang chính: lấy bản mới khi có mạng, mất mạng thì dùng bản đã lưu
  if (req.mode === 'navigate') {
    e.respondWith((async () => {
      try {
        const fresh = await fetch(req);
        const c = await caches.open(VERSION);
        c.put('./', fresh.clone());
        return fresh;
      } catch (err) {
        return (await caches.match('./')) || (await caches.match('index.html')) || Response.error();
      }
    })());
    return;
  }
  // thư viện, phông, dữ liệu OCR: dùng bản đã lưu, chưa có thì tải rồi lưu lại
  e.respondWith((async () => {
    const hit = await caches.match(req, { ignoreSearch: true });
    if (hit && req.cache !== 'reload') return hit;
    try {
      const res = await fetch(req);
      if (res.ok && res.type === 'basic') (await caches.open(VERSION)).put(req, res.clone());
      return res;
    } catch (err) {
      return hit || Response.error();
    }
  })());
});
